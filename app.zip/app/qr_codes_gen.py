import csv
import qrcode
import os

# Generate unique codes
codes = [str(i).zfill(4) for i in range(700)]

# Store the codes in a CSV file
csv_file_path = 'codes.csv'
with open(csv_file_path, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Code'])
    writer.writerows([[code] for code in codes])

# Create the 'qrcodes' folder if it doesn't exist
qr_code_folder = 'qrcodes'
if not os.path.exists(qr_code_folder):
    os.makedirs(qr_code_folder)

# Generate QR codes for each code
for code in codes:
    qr = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data(code)
    qr.make(fit=True)
    img = qr.make_image(fill="black", back_color="white")
    qr_code_path = f'{qr_code_folder}/{code}.png'
    img.save(qr_code_path)
