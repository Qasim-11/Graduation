import csv
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def update_attendance(qr_code):
    rows = []
    with open('database.csv', 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == qr_code:
                row[1] = 'True'  # Set attendance status to True
            rows.append(row)

    with open('database.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(rows)

def check_attendance(qr_code):
    with open('database.csv', 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == qr_code:
                if row[1] == 'True':
                    return 'Already Attended'
                else:
                    update_attendance(qr_code)
                    return 'Welcome'
    return "Doesn't Exist"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/verify', methods=['POST'])
def verify():
    data = request.get_json()
    qr_code = data['qrCode']
    status = check_attendance(qr_code)
    return jsonify({'status': status})

if __name__ == '__main__':
    app.run()
