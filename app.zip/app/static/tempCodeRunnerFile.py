

@app.route("/home")
@app.route("/")
def main():
    database = [
    {
        'country': 'USA',
        'price': 10.99,
        'image': 'https://imgd.aeplcdn.com/1056x594/n/cw/ec/44686/activa-6g-right-front-three-quarter.jpeg?q=75'
    },
    {
        'country': 'Canada',
        'price': 9.99,
        'image': 'canada.jpg'
    },
    {
        'country': 'France',
        'price': 12.99,
        'image': 'france.jpg'
    },
    {
        'country': 'Japan',
        'price': 14.99,
        'image': 'japan.jpg'
    },
    {
        'country': 'Australia',
        'price': 11.99,
        'image': 'australia.jpg'
    }
]

    return render_template( "home.html" , posts=posts)
